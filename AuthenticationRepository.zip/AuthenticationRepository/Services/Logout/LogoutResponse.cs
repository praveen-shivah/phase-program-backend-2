﻿namespace AuthenticationRepository
{
    public class LogoutResponse
    {
        public bool IsSuccessful { get; set; }
    }
}
